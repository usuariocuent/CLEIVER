export const users = [
  { username: 'admin', password: 'admin123', role: 'admin', name: 'Admin', lastName: 'Principal', phone: '5512345678', email: 'admin@example.com' },
  { username: 'admin2', password: 'admin2pass', role: 'admin', name: 'Admin', lastName: 'Secundario', phone: '5511223344', email: 'admin2@example.com' },
  { username: 'empleado', password: 'empleado123', role: 'cashier', name: 'Empleado', lastName: 'Caja', phone: '5587654321', email: 'empleado@example.com' },
];